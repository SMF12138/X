package demo1;

public class L extends Tetromino {
    public L() {
        cells[0] = new Cell(0, 4, Tetris.L);
        cells[1] = new Cell(0, 5, Tetris.L);
        cells[2] = new Cell(0, 6, Tetris.L);
        cells[3] = new Cell(1, 4, Tetris.L);

        //������������ת״̬
        states = new State[4];
        //��ʼ������״̬���������
        states[0] = new State(0, 0, 0, -1, 0, 1, 1, -1);
        states[1] = new State(0, 0, -1, 0, 1, 0, -1, -1);
        states[2] = new State(0, 0, 0, 1, 0, -1, -1, 1);
        states[3] = new State(0, 0, 1, 0, -1, 0, 1, 1);
    }
}
